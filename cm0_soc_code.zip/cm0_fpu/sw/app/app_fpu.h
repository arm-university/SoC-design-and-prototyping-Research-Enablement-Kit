#ifndef APP_FPU_H_
#define APP_FPU_H_

#include "../drivers/soc.h"

void app_fpu(void);

void fpu_add_example(const uint32_t FPU_ADDR);

// Private functions
uint32_t fpu_op_cycle_t0(const uint32_t address, const float* a, const float* b, fpu_op_t op, int N);

#endif /* APP_FPU_H_ */
