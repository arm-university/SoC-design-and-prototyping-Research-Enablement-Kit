    . REK : Research Enablement Kit root folder
    ├── cm0_aes/
        ├── hw/
            ├── wrappers/ : AES cypher IP bus wrappers
                ├── aes_apb_wrapper.v : APB bus wrapper
                └── aes_ahb_wrapper.v : AHB bus wrapper
        └── sw/
            ├── app/ : This demo displays the Lena test image on the LCD of the MPS2+ board, then encrypts the image and decrypts it back. If Button0 is pressed, the AES HW module handles the encryption flow, otherwise the CM0 performs it in software.
            ├── drivers/ : AES cypher drivers
                ├── soc.h : FPU and AES addresses and structure definition, for both APB and AHB buses.
                └── aes.h : AES Core macros and functions
            └── img/ : includes the Lena test image used in the app_display() demo
    ├── cm0_fpu/        
        ├── hw/
            ├── wrappers/ : FPU IP bus wrappers
                ├── fpu_apb_wrapper.v : APB wrapper
                └── fpu_ahb_wrapper.v : AHB wrapper
        └── sw/
            ├── app/ : This demo provides examples for basic Floating-Point operations.
            └── drivers/  : FPU drivers
                └── soc.h : FPU and AES addresses and structure definition, for both APB and AHB buses (same as the previous one).
    ├── README.txt : This Readme file
    └── acc.patch : The patch file allows the user to apply all the system extensions described in the whitePaper into the DesignStart Eval project. In order to apply the patch run in a bash console:
                    $> cd "DesignStart Eval for CM0 root folder"
                    $> patch -p1 < "path to patch"/acc.patch