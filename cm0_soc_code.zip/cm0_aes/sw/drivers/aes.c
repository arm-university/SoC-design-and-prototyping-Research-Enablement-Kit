#include <stdint.h>
#include "aes.h"

void aes_init_key(uint32_t address, aes_key_length_t key_length, uint32_t* key) {
	AES_TypeDef * aes = ((AES_TypeDef  *) address);
	uint32_t i;

	while (aes->AES_STATUS & 1ul == 0); // Wait until Ready

	if (key_length == KEY_LENGTH_256)
		// Setting the 256bit key
		for (i = 0; i < 8; i++)
			aes->AES_KEY[i] = key[i];
	else
		for (i = 0; i < 4; i++)
			aes->AES_KEY[i] = key[i];

	aes->AES_STATUS = (key_length << AES_KEYLEN_BIT) | (1ul << AES_INIT_BIT);
}

void aes_op(uint32_t address, aes_key_length_t key_length, aes_op_t op, uint32_t* plain_in, uint32_t* enc_out) {
	AES_TypeDef * aes = ((AES_TypeDef  *) address);
	uint32_t i;

	while (aes->AES_STATUS & 1ul == 0); // Wait until Ready

	// Loading the plaintext
	for (i = 0; i < 4; i++)
		aes->AES_BLOCK[i] = plain_in[i];

	aes->AES_STATUS = (key_length << AES_KEYLEN_BIT) | (op << AES_ENCDEC_BIT) | (1ul << AES_NEXT_BIT);

	while (aes->AES_STATUS & (1ul << AES_RESVALID_BIT) == 0); // Wait result valid
	
	for (i = 0; i < 4; i++)
		enc_out[i] = aes->AES_RESULT[i];
}