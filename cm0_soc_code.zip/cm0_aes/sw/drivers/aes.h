#ifndef AES_H_
#define AES_H_

#include "soc.h"

void aes_init_key(uint32_t address, aes_key_length_t key_length, uint32_t* key);
void aes_op(uint32_t address, aes_key_length_t key_length, aes_op_t op, uint32_t* plain_in, uint32_t* enc_out);

#endif /* AES_H_ */