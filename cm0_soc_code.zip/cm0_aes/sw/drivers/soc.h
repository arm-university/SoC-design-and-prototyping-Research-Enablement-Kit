#ifndef SOC_H_
#define SOC_H_

#include "CMSDK_CM0.h"
#include "SMM_MPS2.h"

// --------------------------------------------------------------------
// Memory Map
// --------------------------------------------------------------------

// AHB
#define AHB_FPU_ADDR   (CMSDK_AHB_BASE + 0x4000UL)      /* FP co-processor on AHB bus 	  */
#define AHB_AES_ADDR   (CMSDK_AHB_BASE + 0x6000UL)      /* Crypto Core Address on AHB bus */

// APB
#define APB_FPU_ADDR   (MPS2_SSP1_BASE + 0xB000ul)      /* FP co-processor on APB bus 	  */
#define APB_AES_ADDR   (MPS2_SSP1_BASE + 0xC000ul)      /* Crypto Core Address on APB bus */

// --------------------------------------------------------------------
// FPU
// --------------------------------------------------------------------

// Floating Point Co-Processor structure
typedef struct {
	__IO uint32_t STATUS_REG;      // Offset: 0x000 (R/W)  Status Register
	__IO float DATA_A;             // Offset: 0x004 (R/W)  Operand A
	__IO float DATA_B;             // Offset: 0x008 (R/W)  Operand B
	__IO uint32_t RMODE;		   // Offest: 0x00C (R/W)  Round Mode
	__IO uint32_t OP;              // Offset: 0x010 (R/W)  Operation
	__I  float RESULT;             // Offset: 0x014 (R)    Result
} FPU_TypeDef;

// Status bits
#define FPU_READY_BIT    0
#define FPU_VALID_BIT    1
#define FPU_DONE_BIT     2

// FP operations
typedef enum{ FPU_ADD, FPU_SUB, FPU_MULT, FPU_DIV, FPU_SQRT } fpu_op_t;

// FP rounding mode
typedef enum{ RM_NEAR, RM_ZERO, RM_UP, RM_DOWN} fpu_rm_t;

// --------------------------------------------------------------------
// AES
// --------------------------------------------------------------------

// AES Core
typedef struct {
	__IO uint32_t AES_STATUS;      // Offset: 0x000 (R/W)  Status Register
	__IO uint32_t AES_KEY[8];      // Offset: 0x004 (R/W)  Key 256 bits
	__IO uint32_t AES_BLOCK[4];    // Offset: 0x024 (R/W)  Data Block 128 bits
	__I  uint32_t AES_RESULT[4];   // Offset: 0x034 (R)    Result 128 bits
} AES_TypeDef;

// Status bits
#define AES_READY_BIT    0
#define AES_INIT_BIT     1
#define AES_NEXT_BIT     2
#define AES_ENCDEC_BIT   3
#define AES_KEYLEN_BIT   4
#define AES_RESVALID_BIT 5

// Key lengths
typedef enum { KEY_LENGTH_128, KEY_LENGTH_256 } aes_key_length_t;

// AES operations
typedef enum { AES_DEC, AES_ENC } aes_op_t;

#endif /* SOC_H_ */