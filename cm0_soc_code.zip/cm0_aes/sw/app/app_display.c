#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "CMSDK_driver.h"
#include "SMM_MPS2.h"                   
#include "GLCD_SPI_MPS2.h"

#include "uart_stdout.h"
#include "common.h"
#include "app_display.h"

#include "../drivers/soc.h"
#include "aes256.h"

#define IMAGE_HEIGHT 320
#define IMAGE_WIDTH  240
#define IMAGE_DIM    9600

void app_display() {
	aes256_context ctx;
	uint32_t i, button = 0;
	uint32_t * pkey_32;
	// 256bit key
	uint8_t key[32] = { (uint8_t) 0x2b, (uint8_t) 0x7e, (uint8_t) 0x15, (uint8_t) 0xf4, (uint8_t) 0x16, (uint8_t) 0x28, (uint8_t) 0xae, (uint8_t) 0xd2, (uint8_t) 0xa6, (uint8_t) 0xab, (uint8_t) 0xf7,
			(uint8_t) 0x15, (uint8_t) 0x88, (uint8_t) 0x09, (uint8_t) 0xcf, (uint8_t) 0x4f, (uint8_t) 0x3c, (uint8_t) 0x19, (uint8_t) 0x17, (uint8_t) 0xa0, (uint8_t) 0x6e, (uint8_t) 0x92,
			(uint8_t) 0x7a, (uint8_t) 0xfe, (uint8_t) 0xc1, (uint8_t) 0x20, (uint8_t) 0xd2, (uint8_t) 0x5f, (uint8_t) 0x92, (uint8_t) 0xb6, (uint8_t) 0x10, (uint8_t) 0x5e };

	pkey_32 = (uint32_t *) key;

	// Fill display with test pattern bitmap (320*240*16bit RGB 5:6:5)
	GLCD_Bitmap(0, 0, IMAGE_HEIGHT, IMAGE_WIDTH, (unsigned short *) lena);

	printf("\n\nPress button to select demo:\n\tBtn0: Hardware\tBtn1: Software");

	do {
		button = MPS2_FPGAIO->BUTTON;
	} while (!button);

	if (button & 1UL) {
		printf("\nStart Image HW encryption");

		aes_init_key(AHB_AES_ADDR, KEY_LENGTH_256, pkey_32);
		printf("\nHardware key initialized!");

		for (i = 0; i < IMAGE_DIM; i++)
			aes_op(AHB_AES_ADDR, KEY_LENGTH_256, AES_ENC, (uint32_t*) lena + (i * 4), (uint32_t*) lena + (i * 4));
		printf("\nHardware encryption complete!");

		// Fill display with test pattern bitmap (320*240*16bit RGB 5:6:5)
		GLCD_Bitmap(0, 0, IMAGE_HEIGHT, IMAGE_WIDTH, (unsigned short *) lena);

		for (i = 0; i < IMAGE_DIM; i++)
			aes_op(AHB_AES_ADDR, KEY_LENGTH_256, AES_DEC, (uint32_t*) lena + (i * 4), (uint32_t*) lena + (i * 4));
		printf("\nHardware decryption complete!");

		// Fill display with test pattern bitmap (320*240*16bit RGB 5:6:5)
		GLCD_Bitmap(0, 0, IMAGE_HEIGHT, IMAGE_WIDTH, (unsigned short *) lena);

	} else if (button & (1UL << 1)) {
		printf("\nStart Image SW encryption");

		aes256_init(&ctx, key);
		printf("\nSoftware key initialized!");

		for (i = 0; i < IMAGE_DIM; i++)
			aes256_encrypt_ecb(&ctx, (uint8_t*) lena + (i * 16));
		printf("\nSoftware encryption complete!");

		// Fill display with test pattern bitmap (320*240*16bit RGB 5:6:5)
		GLCD_Bitmap(0, 0, IMAGE_HEIGHT, IMAGE_WIDTH, (unsigned short *) lena);

		for (i = 0; i < IMAGE_DIM; i++)
			aes256_decrypt_ecb(&ctx, (uint8_t*) lena + (i * 16));
		printf("\nSoftware decryption completed!");

		// Fill display with test pattern bitmap (320*240*16bit RGB 5:6:5)
		GLCD_Bitmap(0, 0, IMAGE_HEIGHT, IMAGE_WIDTH, (unsigned short *) lena);
	}

	printf("\nDone..");
}