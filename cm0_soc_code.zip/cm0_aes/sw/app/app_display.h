#ifndef APP_DISPLAY_H_
#define APP_DISPLAY_H_

#include "../drivers/soc.h"
#include "../drivers/aes.h"
#include "../../aes/sw_impl/aes256.h"

extern unsigned short lena[];

void app_display(void);

#endif /* APP_DISPLAY_H_ */